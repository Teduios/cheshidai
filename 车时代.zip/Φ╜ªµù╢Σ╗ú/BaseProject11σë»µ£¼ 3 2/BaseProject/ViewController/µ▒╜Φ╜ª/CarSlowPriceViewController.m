//
//  CarSlowPriceViewController.m
//  BaseProject
//
//  Created by iOS－38 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "CarSlowPriceViewController.h"
#import "SlowViewModel.h"
#import "SlowCell.h"
#import "Factory.h"

@interface CarSlowPriceViewController ()<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)SlowViewModel *slowVM;
@end

@implementation CarSlowPriceViewController
-(instancetype)init{
    if (self = [super init]) {
        self.title = @"降价";
        
    }
    return self;
}

-(SlowViewModel *)slowVM{
    if (!_slowVM) {
        _slowVM = [SlowViewModel new];
    }
    return _slowVM;
}
-(UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        //注册表格
        [_tableView registerClass:[SlowCell class] forCellReuseIdentifier:@"cell"];
        //去掉表格的空白页
        _tableView.tableFooterView = [UIView new];
        [self.view addSubview:_tableView];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        
    }
    return _tableView;
}




- (void)viewDidLoad {
    [super viewDidLoad];
    //添加返回菜单的按钮
    [Factory addMenuBtnToVC:self];
    
    
    self.tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
       [self.slowVM refreshDataCompletionHandle:^(NSError *error) {
           if (error) {
               [self showErrorMsg:error.localizedDescription];
           }else{
               [self.tableView reloadData];
           }
           [self.tableView.header endRefreshing];
       }];
    }];
    
    self.tableView.footer = [MJRefreshBackFooter footerWithRefreshingBlock:^{
       [self.slowVM getMoreDataCompletionHandle:^(NSError *error) {
           if (error) {
               [self showErrorMsg:error.localizedDescription];
           }else{
               [self.tableView reloadData];
           }
           [self.tableView.footer endRefreshing];
       }];
    }];
    
    //进来就刷新
    [self.tableView.header beginRefreshing];
    
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.slowVM.rowNumber;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    SlowCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    
    [cell.iconIV setImageWithURL:[self.slowVM iconForRow:indexPath.row]];
    cell.seriesLb.text = [self.slowVM stypeNameForRow:indexPath.row];
    cell.speanameLb.text = [self.slowVM carNameForRow:indexPath.row];

    cell.companyLb.text = [self.slowVM companyNameForRow:indexPath.row];
//
    cell.phoneLb.text = [self.slowVM telephoneForRow:indexPath.row];
    
    cell.nowPriceLb.text = [NSString stringWithFormat:@"现价:%@",[self.slowVM nowPriceForRow:indexPath.row]];
     cell.oldPriceLb.text = [NSString stringWithFormat:@"原价:%@",[self.slowVM oldPriceForRow:indexPath.row]];//
    cell.cityLb.text = [self.slowVM CityNameForRow:indexPath.row];
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 90;
}







@end
