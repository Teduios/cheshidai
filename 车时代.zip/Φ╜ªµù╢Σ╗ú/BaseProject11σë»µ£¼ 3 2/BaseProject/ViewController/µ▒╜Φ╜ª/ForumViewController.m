//
//  ForumViewController.m
//  BaseProject
//
//  Created by iOS－38 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ForumViewController.h"
#import "ForumCell.h"
#import "ForumViewModel.h"


#import "Factory.h"

@interface ForumViewController ()<UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout>
@property(nonatomic,strong)UICollectionView *collectionV;
@property(nonatomic,strong)ForumViewModel *forumVM;
@end

@implementation ForumViewController
-(instancetype)init{
    if (self = [super init]) {
        
        self.title = @"热门";
        
    }
    return self;
}
//栏加载VM
-(ForumViewModel *)forumVM{
    if (!_forumVM) {
        _forumVM = [[ForumViewModel alloc]init];
    }
    return _forumVM;
}

-(UICollectionView *)collectionV{
    if (!_collectionV) {
        _collectionV = [[UICollectionView alloc]initWithFrame:CGRectZero collectionViewLayout:[UICollectionViewFlowLayout new]];
        [self.view addSubview:_collectionV];
        [_collectionV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        
        _collectionV.backgroundColor = [UIColor whiteColor];
        _collectionV.delegate = self;
        _collectionV.dataSource = self;
        //注册表格
        [_collectionV registerClass:[ForumCell class] forCellWithReuseIdentifier:@"cell"];
        
    }
    


    return _collectionV;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor redColor];
    
    //添加返回按钮
    [Factory addMenuBtnToVC:self];
    
    //下拉刷新
    self.collectionV.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.forumVM refreshDataCompletionHandle:^(NSError *error) {
            if (error) {
                [self showErrorMsg:error.localizedDescription];
            }else {
                [self.collectionV reloadData];
            }
            [self.collectionV.header endRefreshing];
        }];
    }];
    
    //加载更多
    self.collectionV.footer = [MJRefreshAutoFooter footerWithRefreshingBlock:^{
        [self.forumVM getMoreDataCompletionHandle:^(NSError *error) {
            if (error) {
                [self showErrorMsg:error.localizedDescription];
            }else {
                [self.collectionV reloadData];
            }
            [self.collectionV.footer endRefreshing];
        }];
    }];
    //进来就刷新
    [self.collectionV.header beginRefreshing];
}


#pragma mark -UICollectionViewDataSource
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
   return  self.forumVM.rowNumber;
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    ForumCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
    [cell.iconIV.imageView setImageWithURL:[self.forumVM iconURLForRow:indexPath.row] placeholderImage:[UIImage imageNamed:@"cell_bg_noData_2"]];

    cell.titleLb.text = [self.forumVM titleForRow:indexPath.row];
    //cell.commentLb.text = [self.forumVM commentCountForRow:indexPath.row];
    return cell;
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    [collectionView deselectItemAtIndexPath:indexPath animated:YES];
 
}

#pragma mark  -UICollectionViewDelegateFlowLayout
//section(分区) 上  下  左  右  的距离
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{

    return UIEdgeInsetsMake(5, 10, 5, 10);
}
//最小的列间距
-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section{
    return 10;
}
//最小的行间距
-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section{
    return 5;
}
//每个cell的宽高
-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
   //共2张图
    CGFloat width = (kWindowW - 3*10)/2;
    CGFloat height = width + 15;
    return CGSizeMake(width, height);
}

//去除分隔线
kRemoveCellSeparator;
@end
