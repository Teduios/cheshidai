//
//  CarPriceListViewController.m
//  BaseProject
//
//  Created by iOS－38 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "CarPriceListViewController.h"
#import "PriceViewModel.h"
#import "PriceCell.h"

#import "Factory.h"

@interface CarPriceListViewController ()<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)PriceViewModel  *priceVM;
@end

@implementation CarPriceListViewController
-(instancetype)init{
    if (self = [super init]) {
        self.title = @"报价";
    }
    return self;
}
-(PriceViewModel *)priceVM{
    if (!_priceVM ) {
        _priceVM = [[PriceViewModel alloc]init];
    }
    return _priceVM;
}
-(UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        [self.view addSubview:_tableView];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        //注册表格
        [_tableView registerClass:[PriceCell class] forCellReuseIdentifier:@"cell"];
        //去除结尾的空白格
        _tableView.tableFooterView = [UIView new];
    }
    return _tableView;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    [Factory addMenuBtnToVC:self];
    self.view.backgroundColor = [UIColor redColor];
    //刷新
    self.tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
       [self.priceVM refreshDataCompletionHandle:^(NSError *error) {
           if (error) {
               [self showErrorMsg:error.localizedDescription];
           }else{
               [self.tableView reloadData];
           }
           [self.tableView.header endRefreshing];
       }];
    }];
    
    //加载更多
    self.tableView.footer = [MJRefreshAutoFooter footerWithRefreshingBlock:^{
        [self.priceVM getMoreDataCompletionHandle:^(NSError *error) {
            if (error) {
                [self showErrorMsg:error.localizedDescription];
            }else{
                [self.tableView reloadData];
            }
            [self.tableView.footer endRefreshing];
            
        }];
    }];
    
    //刚进来就刷新
    [self.tableView.header beginRefreshing];
}


#pragma  -mark  UITableViewDataSource
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.priceVM.rowNumber;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    PriceCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    [cell.iconIV.imageView setImageWithURL:[self.priceVM iconURLForRow:indexPath.row]];
    cell.titleLb.text = [self.priceVM titleForRow:indexPath.row];
    cell.noneLb.text = @"指导价";
    cell.breadnameLb.text =[NSString stringWithFormat:@"品牌:%@",[self.priceVM breadNameForRow:indexPath.row]];
    cell.fctnameLb.text =[NSString stringWithFormat:@"厂商:%@" ,[self.priceVM facnameForRow:indexPath.row]];

    cell.levelLb.text = [NSString stringWithFormat:@"级别:%@",[self.priceVM levelForRow:indexPath.row]];
 
    if ([self.priceVM structureForRow:indexPath.row].count == 0) {
        cell.structLb.text = [NSString stringWithFormat:@"车身结构:--"];
    }else{
        cell.structLb.text =[NSString stringWithFormat:@"车身结构:%@",[self.priceVM structureForRow:indexPath.row][0]];
    }
    
    if (![self.priceVM isExistPriceForRow:indexPath.row]) {
        cell.priceLb.text = @"暂无报价";
    }else{
        cell.priceLb.text = [NSString stringWithFormat:@"%@--%@",[self.priceVM maxpriceForRow:indexPath.row],[self.priceVM minpriceForRow:indexPath.row]];
    }
    
    //变速箱

    if ([self.priceVM gearboxForRow:indexPath.row].count == 0) {
        cell.gearboxLb.text = [NSString stringWithFormat:@"变速箱:--"];
        
    }else{
        cell.gearboxLb.text = [NSString stringWithFormat:@"变速箱:%@",[self.priceVM gearboxForRow:indexPath.row][0]];
    }
//    发动机
    if ([self.priceVM displacementForRow:indexPath.row].count == 0) {
        cell.displamentLb.text = [NSString stringWithFormat:@"发动机:--"];
    }else{
       cell.displamentLb.text = [NSString stringWithFormat:@"发动机:%@",[self.priceVM displacementForRow:indexPath.row][0]];
    }
    return cell;
}


-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    return 120;
}


//去除分隔线
kRemoveCellSeparator;









@end
