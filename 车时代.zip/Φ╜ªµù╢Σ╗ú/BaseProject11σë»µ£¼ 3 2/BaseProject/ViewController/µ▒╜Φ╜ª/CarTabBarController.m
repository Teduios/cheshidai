//
//  CarTabBarController.m
//  BaseProject
//
//  Created by iOS－38 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "CarTabBarController.h"
#import "CarPriceListViewController.h"
#import "ForumViewController.h"
#import "CarSlowPriceViewController.h"


@interface CarTabBarController ()

@end

@implementation CarTabBarController
//创建CarTabBar的单例
+(CarTabBarController *)standardInstance{
   static CarTabBarController *vc = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        vc = [CarTabBarController new];
    });
    return vc;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    //自定义下变的tabBar，先隐藏下面的原生的工具栏
    self.tabBar.translucent = NO;
    //初始化三个子视图,将其放入CartabBar控制器中
    CarPriceListViewController *list = [CarPriceListViewController new];
    list.tabBarItem.image = [UIImage imageNamed:@"ExpressionShops"];
    
    CarSlowPriceViewController *slow = [CarSlowPriceViewController new];
    slow.tabBarItem.image = [UIImage imageNamed:@"f_geili"];
    ForumViewController *forum = [ForumViewController new];
    forum.tabBarItem.image = [UIImage imageNamed:@"h_good"];
    UINavigationController *listNavi = [[UINavigationController alloc]initWithRootViewController:list];
    
    UINavigationController *slowNavi = [[UINavigationController alloc]initWithRootViewController:slow];
    UINavigationController *forumNavi = [[UINavigationController alloc]initWithRootViewController:forum];
    
    self.viewControllers = @[forumNavi,listNavi,slowNavi];
    
}

//点击 进入应用 按钮后 更换根window .在点击按钮触发事件的时候进行全局的导航栏配置
-(void)configGloablUIStype{
    //设置导航栏不透明
    [[UINavigationBar appearance]setTranslatesAutoresizingMaskIntoConstraints:NO];
    //设置导航栏的背景图
    [[UINavigationBar appearance]setBackgroundImage:[UIImage imageNamed:@"navigationbar_bg_64"] forBarMetrics:UIBarMetricsDefault];
    //配置导航栏题目的样式
    [[UINavigationBar appearance]setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor purpleColor],NSFontAttributeName:[UIFont systemFontOfSize:18]}];
}

@end
