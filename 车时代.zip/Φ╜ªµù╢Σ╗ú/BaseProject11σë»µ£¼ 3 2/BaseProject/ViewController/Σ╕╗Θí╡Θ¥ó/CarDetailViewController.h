//
//  CarDetailViewController.h
//  BaseProject
//
//  Created by iOS－38 on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CarDetailViewController : UIViewController
//公开一个属性，用于接收传进来的id
@property(nonatomic,strong)NSNumber *ID;
-initWithId:(NSNumber *)ID;
@end
