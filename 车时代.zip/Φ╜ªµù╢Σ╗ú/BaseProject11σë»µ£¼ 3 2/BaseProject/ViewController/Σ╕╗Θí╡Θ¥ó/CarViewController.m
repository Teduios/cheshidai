//
//  CarViewController.m
//  BaseProject
//
//  Created by iOS－38 on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "CarViewController.h"
#import "CarCell.h"
#import "LatesViewModel.h"


#import "CarDetailViewController.h"

@interface CarViewController ()

@property(nonatomic,strong)LatesViewModel *carVM;

@end

@implementation CarViewController



-(LatesViewModel *)carVM{
    if (!_carVM) {
        _carVM = [[LatesViewModel alloc]initWithNewsListType:_NewsListType.integerValue];
    }
    return _carVM;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"汽车";
    [self.tableView registerClass:[CarCell class] forCellReuseIdentifier:@"cell"];
    

    //刷新
    self.tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.carVM getDataFromNetCompleteHandle:^(NSError *error) {
            if (error) {
                [self showErrorMsg:error.localizedDescription];
            }else{
                [self.tableView reloadData];
//                self.tableView.tableHeaderView = [self headerView];
            }
            [self.tableView.header endRefreshing];
        }];
    }];
    
    //下拉加载更多
    self.tableView.footer = [MJRefreshAutoFooter footerWithRefreshingBlock:^{
        [self.carVM getMoreDataCompletionHandle:^(NSError *error) {
            if (error) {
                [self showErrorMsg:error.localizedDescription];
            }else{
                [self.tableView reloadData];
//                self.tableView.tableHeaderView = [self headerView];
            }
            [self.tableView.footer endRefreshing];
            
        }];
    }];
    //刚进来就刷新
    [self.tableView.header beginRefreshing];
    
    //去掉脚步的空白格
    self.tableView.tableFooterView = [UIView new];
}

#pragma mark - UITableViewDataSource
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.carVM.rowNumber;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    CarCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    cell.titleLb.text = [self.carVM titleForRow:indexPath.row];
    [cell.iconIV setImageWithURL:[self.carVM iconURLForRow:indexPath.row]  placeholderImage:[UIImage imageNamed:@"cell_bg_noData_2"]];
    cell.commentLb.text = [self.carVM commentNumberForRow:indexPath.row];
    cell.dateLb.text = [self.carVM dateForRow:indexPath.row];
    return cell;
}


//删除分隔线
kRemoveCellSeparator

//点击某一行推出详情界面
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    //通过接口知道详情界面需要传递一个 ID值
    CarDetailViewController *vc = [[CarDetailViewController alloc]initWithId:[self.carVM IDForRow:indexPath.row]];
    [self.navigationController pushViewController:vc animated:YES];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 70;
}


@end
