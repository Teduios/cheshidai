//
//  CarViewController.h
//  BaseProject
//
//  Created by iOS－38 on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LatesViewModel.h"

@interface CarViewController : UITableViewController
//接收外部传的参数，决定当前控制器显示哪种类型的信息
@property(nonatomic)NSNumber *NewsListType;
@end
