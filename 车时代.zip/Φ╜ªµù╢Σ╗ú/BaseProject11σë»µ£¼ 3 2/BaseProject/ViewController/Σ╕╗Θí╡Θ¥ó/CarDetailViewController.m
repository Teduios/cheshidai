//
//  CarDetailViewController.m
//  BaseProject
//
//  Created by iOS－38 on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "CarDetailViewController.h"
#import "Factory.h"

@interface CarDetailViewController ()<UIWebViewDelegate>
@property(nonatomic,strong)UIWebView  *webView;
@end

@implementation CarDetailViewController
-(id)initWithId:(NSNumber *)ID{
    if (self = [super init]) {
        self.ID = ID;
    }
    return self;
}
-(UIWebView *)webView{
    if (!_webView) {
        _webView = [UIWebView new];
        [self.view addSubview:_webView];
        [_webView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        _webView.delegate = self;
    }

    return _webView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"详情";
    //添加返回按钮
    [Factory addBackBtnToVC:self];
    
    NSString *path = [NSString stringWithFormat:@"http://cont.app.autohome.com.cn/autov5.0.0/content/news/newscontent-n%@-t0-rct1.json", _ID];
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:path]];
    [self.webView loadRequest:request];
}

#pragma mark -UIWebViewDelegate
- (void)webViewDidStartLoad:(UIWebView *)webView{
    [self showProgress];
}

- (void)webViewDidFinishLoad:(UIWebView *)webView{
    [self hideProgress];
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(nullable NSError *)error{
    [self showProgress];
}


@end
