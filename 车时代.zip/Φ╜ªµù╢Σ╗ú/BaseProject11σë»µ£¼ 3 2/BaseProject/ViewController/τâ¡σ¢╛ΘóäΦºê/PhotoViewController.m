//
//  PhotoViewController.m
//  BaseProject
//
//  Created by iOS－38 on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "PhotoViewController.h"
#import "iCarousel.h"
#import "Factory.h"

@interface PhotoViewController ()<iCarouselDelegate,iCarouselDataSource>
@property(nonatomic,strong)NSArray *ImageName;
@property(nonatomic,strong)iCarousel *ic;
@end

@implementation PhotoViewController
+(UINavigationController *)standardNavi{
   static UINavigationController *navi = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        PhotoViewController *vc = [PhotoViewController new];
        navi = [[UINavigationController alloc]initWithRootViewController:vc];
    });
    return navi;
}
-(iCarousel *)ic{
    if (!_ic) {
        _ic = [iCarousel new];
        //仿写的collectionView。设置代理
        _ic.delegate = self;
        _ic.dataSource = self;
        //设置3D的显示模式。3的效果很好type是枚举值，数值0-11
        _ic.type = 3;
        //设置自动展示，0表示不滚动，数值越大，滚动的越快
        //_ic.autoscroll = 2;
        //设置改变为竖直展示
        _ic.vertical = NO;
        //设置滚动速度
        _ic.scrollSpeed = 0;
        //改为翻页模式，条件:将type改为0.自动展示和竖直都为NO,将图片大小改为屏幕宽高.并遵守协议，去掉白边
        _ic.pagingEnabled = YES;
    }
    return _ic;
}
//懒加载图片数组
-(NSArray *)ImageName{
    if (!_ImageName) {
        //读取HeroSkins.bundle文件夹的所有文件名
        NSString *path = [[NSBundle mainBundle]pathForResource:@"photoo" ofType:@"bundle"];
        //读取文件夹下的所有的子文件的路径
        _ImageName = [[NSFileManager defaultManager]subpathsAtPath:path];
    }
    return _ImageName;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"热图预览";
    
    //添加会菜单的按钮
    [Factory addMenuBtnToVC:self];
    
    //将3D试图添加到本控制器的界面上
    [self.view addSubview:self.ic];
    //设置3D视图的位置约束
    [self.ic mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
    
    //设置定时器自动滚动
        [NSTimer bk_scheduledTimerWithTimeInterval:1 block:^(NSTimer *timer) {
            [self.ic scrollToItemAtIndex:self.ic.currentItemIndex+1 animated:YES];
        } repeats:YES];
    
}

#pragma mark - iCarouselDataSource
//有多少项
- (NSInteger)numberOfItemsInCarousel:(iCarousel *)carousel{
    return self.ImageName.count;
}
//每个View什么样
- (UIView *)carousel:(iCarousel *)carousel viewForItemAtIndex:(NSInteger)index reusingView:(nullable UIView *)view{
    if (!view) {   //如果重用视图不存在
        //这里的x,y是没有用的，图片的宽高 300*500
        view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, kWindowW/1.2, kWindowH/1.2)];
        //设置view上的图片视图
        UIImageView *imageView = [UIImageView new];
        imageView.tag = 100;
        [view addSubview:imageView];
        //设置图片视图的位置约束
        [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
    }
    UIImageView *imageView = (UIImageView *)[view viewWithTag:100];
    NSString *path = [[NSBundle mainBundle]pathForResource:@"photoo" ofType:@"bundle"];
    path = [path stringByAppendingPathComponent:self.ImageName[index]];
    imageView.image = [UIImage imageWithContentsOfFile:path];
    
    return view;
    
}
//设置每个cell之间的间隔距离
-(CGFloat)carouselItemWidth:(iCarousel *)carousel{
    return kWindowW-1;
}

//添加循环滚动
-(CGFloat)carousel:(iCarousel *)carousel valueForOption:(iCarouselOption)option withDefault:(CGFloat)value{
    if (option == iCarouselOptionWrap) {
        return YES; //type0的默认循环滚动模式是 否
    }
    
    //修改缝隙()
    if (option == iCarouselOptionSpacing) {
        return value;
    }
    
    //取消后背的显示(这样的效果不好，不建议使用)
    //    if (option == iCarouselOptionShowBackfaces) {
    //        return NO;
    //    }
    return value;
}







@end
