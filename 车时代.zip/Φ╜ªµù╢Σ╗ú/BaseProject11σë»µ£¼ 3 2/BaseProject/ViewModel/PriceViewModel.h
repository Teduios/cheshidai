//
//  PriceViewModel.h
//  BaseProject
//
//  Created by iOS－38 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "CarPriceNetModel.h"

@interface PriceViewModel : BaseViewModel

//行数
@property(nonatomic)NSInteger rowNumber;
//页数
@property(nonatomic)NSInteger pageIndex;

//图片
-(NSURL *)iconURLForRow:(NSInteger)row;
//标题
-(NSString *)titleForRow:(NSInteger)row;
//品牌
-(NSString *)breadNameForRow:(NSInteger)row;
//厂商
-(NSString *)facnameForRow:(NSInteger)row;
//级别
-(NSString *)levelForRow:(NSInteger)row;
//最高报价
-(NSString *)maxpriceForRow:(NSInteger)row;
//最低报价
-(NSString *)minpriceForRow:(NSInteger)row;


//车身结构
-(NSArray *)structureForRow:(NSInteger)row;
//变速箱
-(NSArray *)gearboxForRow:(NSInteger)row;
//发动机
-(NSArray *)displacementForRow:(NSInteger)row;



//价格是否存在


-(BOOL)isExistPriceForRow:(NSInteger)row;
@end
