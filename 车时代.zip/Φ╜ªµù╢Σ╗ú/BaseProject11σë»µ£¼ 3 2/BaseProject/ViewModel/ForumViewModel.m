//
//  ForumViewModel.m
//  BaseProject
//
//  Created by iOS－38 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ForumViewModel.h"

@implementation ForumViewModel
//行数
-(NSInteger)rowNumber{
    return self.dataArr.count;
}

-(CarResultListModel *)modelForRow:(NSInteger)row{
    return self.dataArr[row];
}



//图片
-(NSURL *)iconURLForRow:(NSInteger)row{
    return [NSURL URLWithString:[self modelForRow:row].smallpic];
}
//标题
-(NSString *)titleForRow:(NSInteger)row{
    return [self modelForRow:row].title;
}
//浏览量
-(NSString *)scanForRow:(NSInteger)row{
    return [NSString stringWithFormat:@"%ld",[self modelForRow:row].views];
}
//评论数
-(NSString *)commentCountForRow:(NSInteger)row{
    return [NSString stringWithFormat:@"%ld",[self modelForRow:row].replycounts];
}

//刷新
-(void)refreshDataCompletionHandle:(CompletionHandle)completionHandle{
    _pageIndex = 1;
    [self getDataFromNetCompleteHandle:completionHandle];

}
//下拉加载更多
-(void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle{
    _pageIndex += 20;
    [self getDataFromNetCompleteHandle:completionHandle];
}

//获得数据
-(void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
   self.dataTask = [ForumNetModel getForumDataWithPageIndex:_pageIndex completionHandle:^(ForumModel *model, NSError *error) {
       if (_pageIndex == 1) {
           [self.dataArr removeAllObjects];
       }
       [self.dataArr addObjectsFromArray:model.result.list];
       completionHandle(error);
   }];
}




@end
