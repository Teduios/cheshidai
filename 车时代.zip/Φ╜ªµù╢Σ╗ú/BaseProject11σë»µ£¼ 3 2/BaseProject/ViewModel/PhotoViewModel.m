//
//  PhotoViewModel.m
//  BaseProject
//
//  Created by iOS－38 on 15/11/15.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "PhotoViewModel.h"

@implementation PhotoViewModel
//下拉刷新
-(void)refreshDataCompletionHandle:(CompletionHandle)completionHandle{
    _pageId = 10;
    [self getDataFromNetCompleteHandle:completionHandle];
}

//加载更多
-(void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle{
    _pageId += 10;
    [self getDataFromNetCompleteHandle:completionHandle];
}

//http://app.api.autohome.com.cn/autohdv2.6/cars/newestseriespic-a4-pm5-v2.6.1-s18.html
//获得数据
-(void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{

   self.dataTask = [PhotoNetModel getPhotoWithPageId:_pageId completionHandle:^(PhotoModel *model, NSError *error) {
       if (_pageId == 1) {
           [self.dataArr removeAllObjects];
       }
       [self.dataArr addObjectsFromArray:model.result.seriesitems];
       completionHandle(error);
   }];
}







-(PhotoResultSeriesitemsModel *)modelForROw:(NSInteger)row{
    return self.dataArr[row];
}

-(NSURL *)iconURLWithRow:(NSInteger)row{
    return [NSURL URLWithString:[self modelForROw:row].picfilepath];
}

-(NSString *)titleForRow:(NSInteger)row{
    return [self modelForROw:row].name;
}

-(NSInteger)rowNumber{
    return self.dataArr.count;
}




@end
