//把汽车资讯当成主界面，


#import <UIKit/UIKit.h>
#import "WMPageController.h"



@interface MainViewController : WMPageController
//设置单例（并且自带导航控制器）
+(UINavigationController *)shandardMainNavi;



@end
