//
//  LeftViewController.m
//  BaseProject
//
//  Created by iOS－38 on 15/11/10.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "LeftViewController.h"
#import "MainViewController.h"
#import "CarTabBarController.h"
#import "PhotoViewController.h"

@interface LeftViewController ()<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong)NSArray *itemNames;
@property(nonatomic,strong)UITableView *tableView;
@end

@implementation LeftViewController
-(NSArray *)itemNames{
    return @[@"汽车资讯",@"最新价位",@"热图预览"];
}
-(UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        [_tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
        _tableView.tableFooterView = [UIView new];
        _tableView.backgroundColor = [UIColor clearColor];
        [self.view addSubview:_tableView];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(0);
            make.centerY.mas_equalTo(0);
            make.size.mas_equalTo(CGSizeMake(kWindowW/2, kWindowH/2));
        }];
        //去掉分隔线
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    }
    return _tableView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
/*--------------必须触发table的懒加载才行，否则数据不能显示-----------------*/
    [self.tableView reloadData];
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return  self.itemNames.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    cell.accessoryType = 1;
    cell.textLabel.text = self.itemNames[indexPath.row];
    cell.backgroundColor = [UIColor clearColor];
    cell.contentView.backgroundColor = [UIColor clearColor];
    cell.textLabel.textColor = [UIColor blueColor];
    
    return cell;
}

//点击某一行推出新的界面
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    switch (indexPath.row) {
        case 0:
            [self.sideMenuViewController setContentViewController:[MainViewController shandardMainNavi] animated:YES];
            [self.sideMenuViewController hideMenuViewController];
            break;
         case 1:
            [self.sideMenuViewController setContentViewController:[CarTabBarController standardInstance] animated:YES];
            [self.sideMenuViewController hideMenuViewController];
            break;
          case 2:
            [self.sideMenuViewController setContentViewController:[PhotoViewController standardNavi] animated:YES];
            [self.sideMenuViewController hideMenuViewController];
            break;
        default:
            break;
    }

}
@end
