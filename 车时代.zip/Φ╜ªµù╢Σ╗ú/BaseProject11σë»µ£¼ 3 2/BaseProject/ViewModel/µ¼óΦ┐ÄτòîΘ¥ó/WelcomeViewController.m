//
//  WelcomeViewController.m
//  BaseProject
//
//  Created by iOS－38 on 15/11/10.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "WelcomeViewController.h"
#define MAXIMAGECOUNT 4

#import "MainViewController.h"
#import "LeftViewController.h"
@interface WelcomeViewController ()<UIScrollViewDelegate>
@property(nonatomic,strong)UIScrollView *scrollView;
@property(nonatomic,strong)UIPageControl *pageControl;

@end

@implementation WelcomeViewController
-(UIScrollView *)scrollView{
    if (!_scrollView) {
        _scrollView = [UIScrollView new];
        //设置滚动视图的代理
        _scrollView.delegate = self;
        //设置滚动视图的frame(可见区域)
        _scrollView.frame = self.view.bounds;
        //配置边缘不可以弹跳
        _scrollView.bounces = NO;
        //设置整页滚动
        _scrollView.pagingEnabled = YES;
        //设置水平滚动条不可见
        _scrollView.showsHorizontalScrollIndicator = NO;
        _scrollView.contentSize = CGSizeMake(MAXIMAGECOUNT*_scrollView.frame.size.width, 0);
        //向滚动视图中添加自视图
        for (int i = 0; i < MAXIMAGECOUNT; i++) {
            UIImageView *imageView = [UIImageView new];
            NSString *imageName = [NSString stringWithFormat:@"welcome%d",i+1];
            imageView.image = [UIImage imageNamed:imageName];
            
            imageView.frame = CGRectMake(i*_scrollView.frame.size.width, 0, _scrollView.frame.size.width, _scrollView.frame.size.height);
            [_scrollView addSubview:imageView];
            if (i == MAXIMAGECOUNT-1) {
                UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
                [btn setTitle:@"点击进入应用" forState:UIControlStateNormal];
                [btn setTitleColor:kRGBColor(109, 75, 48) forState:UIControlStateNormal];
                [btn setBackgroundColor:[UIColor greenColor]];
//                //建立闪光区域，所有在闪光区域内的控件都会闪
                FBShimmeringView *sv = [FBShimmeringView new];
               //把按钮放入闪光区，必须这样写，不能addSubView
                sv.contentView = btn;
                [btn mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.edges.mas_equalTo(0);
                }];
                btn.layer.cornerRadius = 10;
                //开启图片的交互功能
                imageView.userInteractionEnabled = YES;
                [imageView addSubview:sv];
                [sv mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.size.mas_equalTo(CGSizeMake(150, 30));
                    make.centerX.mas_equalTo(0);
                    make.top.mas_equalTo(100);
                }];
                
                //开启闪光功能
                sv.shimmering = YES;
                [btn bk_addEventHandler:^(id sender) {
                    //创建新界面的实例
                    //MainViewController *vc = [[MainViewController alloc]init];
//为了进入主页面需要更换window的根视图控制器为mainViewController
                    //获取根window
                    UIWindow *window = [UIApplication sharedApplication].keyWindow;
                    window.rootViewController = self.sideMenu;
                    
                } forControlEvents:UIControlEventTouchUpInside];
            }
        }
    }
    return _scrollView;
}
-(UIPageControl *)pageControl{

    if (!_pageControl) {
        _pageControl = [UIPageControl new];
        _pageControl.frame = CGRectMake(0, self.view.frame.size.height-60, self.view.frame.size.width, 40);
        _pageControl.pageIndicatorTintColor = [UIColor redColor];
        _pageControl.currentPageIndicatorTintColor = [UIColor blackColor];
        _pageControl.numberOfPages = MAXIMAGECOUNT;
        _pageControl.userInteractionEnabled = NO;
    }
    return _pageControl;
}
- (void)viewDidLoad {
    [super viewDidLoad];
   
    //设置控制器自带的那个界面的背景颜色
    self.view.backgroundColor = [UIColor blackColor];
       //将滚动视图添加到当前页面
    [self.view addSubview:self.scrollView];
    
   
    //将小圆点空间添加到本视图控制器上
    [self.view addSubview:self.pageControl];
    
}
#pragma mark -UIScrollViewDelegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView;{
   
    CGPoint offset = scrollView.contentOffset;
   double i = offset.x/scrollView.frame.size.width;
    self.pageControl.currentPage = round(i);
}


//懒加载左边框(使用第三方框架RESideMenu)
-(RESideMenu *)sideMenu{
    if (!_sideMenu) {
        _sideMenu = [[RESideMenu alloc]initWithContentViewController:[MainViewController shandardMainNavi] leftMenuViewController:[LeftViewController new] rightMenuViewController:nil];
        //为侧边框设置背景色
        _sideMenu.backgroundImage = [UIImage imageNamed:@"1234.jpg"];
//不允许菜单栏缩小到了边缘还可以缩小
        _sideMenu.bouncesHorizontally = NO;
        //可以让出现菜单时不显示状态栏
        _sideMenu.menuPrefersStatusBarHidden = YES;
        
    }
    return _sideMenu;
}






@end
