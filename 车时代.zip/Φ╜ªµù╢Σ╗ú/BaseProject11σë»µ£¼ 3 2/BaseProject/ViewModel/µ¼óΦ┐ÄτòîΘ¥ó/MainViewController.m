/**
 *  构造方法，请使用该方法创建控制器.
 *  Init method，recommend to use this instead of `-init`.
 *
 *  @param classes 子控制器的 class，确保数量与 titles 的数量相等
 *  @param titles  各个子控制器的标题，用 NSString 描述
 *
 *  @return instancetype
 */
//- (instancetype)initWithViewControllerClasses:(NSArray *)classes andTheirTitles:(NSArray *)titles;


#import "MainViewController.h"
#import "CarViewController.h"
#import "Factory.h"


@interface MainViewController ()
@end

@implementation MainViewController
//设置单例（并且自带导航控制器）
+(UINavigationController *)shandardMainNavi{
    static UINavigationController *navi = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        MainViewController *vc = [[MainViewController alloc]initWithViewControllerClasses:[self viewControllerClasses] andTheirTitles:[self itemNames]];
        //例如设置第一个控制器的某个属性的值, KVC
        //vc setValue:[values[0]] forKey:keys[0]
        vc.keys = [self VCKeys];
        vc.values = [self vcValues];
        
        navi = [[UINavigationController alloc]initWithRootViewController:vc];
        
    });
    return navi;
}

//提供题目数组
+(NSArray *)itemNames{
    return @[@"最新",@"新闻",@"评测",@"导购",@"行情",@"用车",@"技术",@"文化",@"改装",@"游记"];
    
}
/** 提供每个题目对应的控制器的类型。题目和类型数量必须一致 */
+(NSArray *)viewControllerClasses{
    NSMutableArray *arr = [NSMutableArray new];
    for (id obj in [self itemNames]) {
        [arr addObject:[CarViewController class]];
    }
    return [arr copy];
}
//提供每个VC对应的key数组
+(NSArray *)VCKeys{
    NSMutableArray *arr = [NSMutableArray new];
    for (id obj in [self itemNames]) {
        [arr addObject:@"NewsListType"];
    }
    return [arr copy];
}
/** 提供每个VC对应的values值数组 */
+ (NSArray *)vcValues{
    NSMutableArray *arr = [NSMutableArray new];
    for (int i = 0; i <[self itemNames].count; i++) {
        //数值上，vc的infoType的枚举值 恰好和i值相同
        [arr addObject:@(i)];
    }
    return arr;
}


//此处已定要在 页面即将加载的时候设置标题  viewDidLoad是进入页面直接加载
-(void)viewWillAppear:(BOOL)animated{
    self.title = @"汽车资讯";
    //添加菜单按钮
    [Factory addMenuBtnToVC:self];
}
//-(void)viewDidLoad{
//self.title = @"tuskn";
//}








@end
