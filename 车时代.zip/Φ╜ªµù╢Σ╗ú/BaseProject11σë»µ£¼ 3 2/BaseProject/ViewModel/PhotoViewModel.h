//
//  PhotoViewModel.h
//  BaseProject
//
//  Created by iOS－38 on 15/11/15.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "PhotoNetModel.h"

@interface PhotoViewModel : BaseViewModel
//行数
@property(nonatomic)NSInteger rowNumber;


-(NSURL *)iconURLWithRow:(NSInteger)row;

-(NSString *)titleForRow:(NSInteger)row;



@property(nonatomic)NSInteger pageId;
@end
