//
//  SlowViewModel.m
//  BaseProject
//
//  Created by iOS－38 on 15/11/15.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "SlowViewModel.h"

@implementation SlowViewModel
//刷新
-(void)refreshDataCompletionHandle:(CompletionHandle)completionHandle{
    _pageId = 0;
    [self getDataFromNetCompleteHandle:completionHandle];
}
//加载更多
-(void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle{
    _pageId += 1;
    [self getDataFromNetCompleteHandle:completionHandle];
}
//获得数据
-(void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
//将id model改为
  self.dataTask = [SlowNetModel getSlowDataWithPageId:_pageId completionHandle:^(SlowModel *model, NSError *error) {
      if (_pageId == 0) {
          [self.dataArr removeAllObjects];
      }
      [self.dataArr addObjectsFromArray:model.result.list];
      completionHandle(error);
  }];
}

//返回对应的数据类型
-(SlowResultListmodel *)modelForRow:(NSInteger)row{
    return self.dataArr[row];
}

-(NSInteger)rowNumber{
    return self.dataArr.count;
}



//公司名称
-(NSString *)companyNameForRow:(NSInteger)row{
    return [self modelForRow:row].companysimple;
}
//图片
-(NSURL *)iconForRow:(NSInteger)row{
    return [NSURL URLWithString:[self modelForRow:row].specimage];
}
//原价
-(NSString *)oldPriceForRow:(NSInteger)row{
    return  [NSString stringWithFormat:@"%@万",[self modelForRow:row].originalprice];
}
//现价
-(NSString *)nowPriceForRow:(NSInteger)row{
 return  [NSString stringWithFormat:@"%@万",[self modelForRow:row].price];
}
//车名称
-(NSString *)carNameForRow:(NSInteger)row{
    return [self modelForRow:row].specname;
}
//联系电话
-(NSString *)telephoneForRow:(NSInteger)row{
    NSMutableString *str1 = [[NSMutableString alloc]initWithString:[self modelForRow:row].sellphone];
    [str1 insertString:@"-" atIndex:3];
    [str1 insertString:@"-" atIndex:7];
    return str1;
}

//城市名称
-(NSString *)CityNameForRow:(NSInteger)row{
    return [self modelForRow:row].cityname;
}
//车类型
-(NSString *)stypeNameForRow:(NSInteger)row{
    return [self modelForRow:row].seriesname;
}
























@end
