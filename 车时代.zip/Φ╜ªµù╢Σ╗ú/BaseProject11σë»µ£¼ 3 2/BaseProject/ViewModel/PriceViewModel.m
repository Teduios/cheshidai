//
//  PriceViewModel.m
//  BaseProject
//
//  Created by iOS－38 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "PriceViewModel.h"

@implementation PriceViewModel
-(NSInteger)rowNumber{
    return self.dataArr.count;
}
//刷新
-(void)refreshDataCompletionHandle:(CompletionHandle)completionHandle{
    _pageIndex = 1;
    [self getDataFromNetCompleteHandle:completionHandle];
}
//加载更多
-(void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle{
    _pageIndex += 1;
    [self getDataFromNetCompleteHandle:completionHandle];
}
//获得数据
-(void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
    //将id model 改为CarPriceModel  *model
    self.dataTask = [CarPriceNetModel getPriceDataWithPageIndex:_pageIndex completionHandle:^(CarPriceModel  *model, NSError *error) {
        if (_pageIndex == 1) {
            [self.dataArr removeAllObjects];
        }
        [self.dataArr addObjectsFromArray:model.result.list];
        completionHandle(error);
    }];
}

-(PriceResultListModel *)modelForRow:(NSInteger)row{
    return self.dataArr[row];
}

//图片
-(NSURL *)iconURLForRow:(NSInteger)row{
    return [NSURL URLWithString:[self modelForRow:row].img];
}
//标题
-(NSString *)titleForRow:(NSInteger)row{
    return [self modelForRow:row].name;
}
//品牌
-(NSString *)breadNameForRow:(NSInteger)row{
    return [self modelForRow:row].brandname;
}
//厂商
-(NSString *)facnameForRow:(NSInteger)row{
    return [self modelForRow:row].fctname;
}
//级别
-(NSString *)levelForRow:(NSInteger)row{
    return [self modelForRow:row].level;
}

//最高报价
-(NSString *)maxpriceForRow:(NSInteger)row{
    return [NSString stringWithFormat:@"%ld",[self modelForRow:row].maxprice];
}
//最低报价
-(NSString *)minpriceForRow:(NSInteger)row{
    return [NSString stringWithFormat:@"%ld",[self modelForRow:row].minprice];
}



//车身结构
-(NSArray *)structureForRow:(NSInteger)row{
    return [self modelForRow:row].structure;
}

//变速箱
-(NSArray *)gearboxForRow:(NSInteger)row{
    return [self modelForRow:row].gearbox;
}

//发动机
-(NSArray *)displacementForRow:(NSInteger)row{
    return [self modelForRow:row].displacement;
}


-(BOOL)isExistPriceForRow:(NSInteger)row{
    if ([self modelForRow:row].maxprice == 0 || [self modelForRow:row].minprice == 0) {
        return NO;
    }
    return YES;
}



@end
