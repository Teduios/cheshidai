//
//  SlowViewModel.h
//  BaseProject
//
//  Created by iOS－38 on 15/11/15.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "SlowNetModel.h"

@interface SlowViewModel : BaseViewModel





//行号
@property(nonatomic)NSInteger rowNumber;

//公司名称
-(NSString *)companyNameForRow:(NSInteger)row;
//图片
-(NSURL *)iconForRow:(NSInteger)row;
//原价
-(NSString *)oldPriceForRow:(NSInteger)row;
//现价
-(NSString *)nowPriceForRow:(NSInteger)row;
//车名称
-(NSString *)carNameForRow:(NSInteger)row;
//联系电话
-(NSString *)telephoneForRow:(NSInteger)row;
//城市名称
-(NSString *)CityNameForRow:(NSInteger)row;
//车类型
-(NSString *)stypeNameForRow:(NSInteger)row;



//页数
@property(nonatomic)NSInteger pageId;







@end
