//
//  ForumViewModel.h
//  BaseProject
//
//  Created by iOS－38 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "ForumNetModel.h"


@interface ForumViewModel : BaseViewModel
//行数
@property(nonatomic)NSInteger rowNumber;


//图片
-(NSURL *)iconURLForRow:(NSInteger)row;
//标题
-(NSString *)titleForRow:(NSInteger)row;
//浏览量
-(NSString *)scanForRow:(NSInteger)row;
//评论数
-(NSString *)commentCountForRow:(NSInteger)row;


//页的下标
@property(nonatomic)NSInteger pageIndex;


@end
