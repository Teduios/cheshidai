//
//  LatesViewModel.h
//  BaseProject
//
//  Created by iOS－38 on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "NewsNetManager.h"

@interface LatesViewModel : BaseViewModel
- (id)initWithNewsListType:(NewsListType)type;
@property(nonatomic) NewsListType type;

@property(nonatomic) NSInteger rowNumber;
//分页加载，必须要有可变的字典
//@property(nonatomic,strong) NSMutableArray *dataArr;
//头部滚动栏，图片数组
@property(nonatomic,strong) NSArray *headImageURLs;

- (NSURL *)iconURLForRow:(NSInteger)row;
- (NSString *)titleForRow:(NSInteger)row;
- (NSString *)dateForRow:(NSInteger)row;
- (NSString *)commentNumberForRow:(NSInteger)row;


//用于传给点击某一行后推出详情界面
- (NSNumber *)IDForRow:(NSInteger)row;

@property(nonatomic,strong) NSString *updateTime;
@property(nonatomic) NSInteger page;
@end
