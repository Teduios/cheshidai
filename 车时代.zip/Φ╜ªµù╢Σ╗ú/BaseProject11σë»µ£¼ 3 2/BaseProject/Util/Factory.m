//
//  Factory.m
//  BaseProject
//
//  Created by iOS－38 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "Factory.h"

@implementation Factory


//向某个控制器上，添加菜单按钮
+(void)addMenuBtnToVC:(UIViewController *)vc{
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setBackgroundImage:[UIImage imageNamed:@"btn_back_h"] forState:UIControlStateNormal];
    [btn setBackgroundImage:[UIImage imageNamed:@"btn_back_n"] forState:UIControlStateHighlighted];
    btn.frame = CGRectMake(0, 0, 30, 30);
    [btn bk_addEventHandler:^(id sender) {
        [vc.sideMenuViewController presentLeftMenuViewController];
    } forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *menu = [[UIBarButtonItem alloc]initWithCustomView:btn];
    
     //使用弹簧控件缩小菜单按钮和边缘距离
    UIBarButtonItem *spaceItem = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
    spaceItem.width = -10;
    vc.navigationItem.leftBarButtonItems = @[spaceItem,menu];

}


//向某个控制器上，添加返回按钮
+(void)addBackBtnToVC:(UIViewController *)vc{
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setTitle:@"上一页" forState:UIControlStateNormal];
    [btn setTintColor:[UIColor redColor]];
    
    btn.frame = CGRectMake(0, 0, 70, 30);
    [btn bk_addEventHandler:^(id sender) {
        [vc.navigationController popToRootViewControllerAnimated:YES];
    } forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *menu = [[UIBarButtonItem alloc]initWithCustomView:btn];
    
    //使用弹簧控件缩小菜单按钮和边缘距离
    UIBarButtonItem *spaceItem=[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
    spaceItem.width = -16;
    vc.navigationItem.leftBarButtonItems = @[spaceItem,menu];
    

}


+(void)configGloablUIStype:(UIViewController *)vc{
    UINavigationBar *navi = [UINavigationBar new];
    //设置导航栏不透明
    [[UINavigationBar appearance]setTranslatesAutoresizingMaskIntoConstraints:NO];
    //设置导航栏的背景图
    [[UINavigationBar appearance]setBackgroundImage:[UIImage imageNamed:@"44.png"] forBarMetrics:UIBarMetricsDefault];
    //配置导航栏题目的样式
    [[UINavigationBar appearance]setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor purpleColor],NSFontAttributeName:[UIFont systemFontOfSize:18]}];
    
    
   
}
@end
