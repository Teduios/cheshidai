//
//  AppDelegate.m
//  BaseProject
//
//  Created by jiyingxin on 15/10/21.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "AppDelegate.h"
#import "AppDelegate+Category.h"
#import "WelcomeViewController.h"

//测试请求数据导入的头文件
#import "ForumNetModel.h"
#import "CarPriceNetModel.h"
#import "SlowNetModel.h"
#import "PhotoNetModel.h"
#import "MainViewController.h"
@interface AppDelegate ()

@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    [self initializeWithApplication:application];

    
    
    self.window = [[UIWindow alloc]initWithFrame:[[UIScreen mainScreen]bounds]];
    self.window.rootViewController = [[WelcomeViewController alloc]init];
    [self.window makeKeyAndVisible];
//测试论坛的数据请求  测试通过
//    [ForumNetModel getForumDataWithPageIndex:6 completionHandle:^(id model, NSError *error) {
//        NSLog(@"11111");
//    }];
//测试报价的数据请求   测试通过
//  [CarPriceNetModel getPriceDataWithPageIndex:1 completionHandle:^(id model, NSError *error) {
//      NSLog(@"11111");
//  }];
//测试降价的数据请求   测试通过
//    [SlowNetModel getSlowDataWithPageId:3 completionHandle:^(id model, NSError *error) {
//        NSLog(@"1111");
//    }];
//测试图片的数据请求 测试通过
//    [PhotoNetModel getPhotoWithPageId:5 completionHandle:^(id model, NSError *error) {
//        NSLog(@"111");
//    }];
    return YES;
}

@end
