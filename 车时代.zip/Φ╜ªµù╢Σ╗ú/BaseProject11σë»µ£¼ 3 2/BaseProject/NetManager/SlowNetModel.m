//
//  SlowNetModel.m
//  BaseProject
//
//  Created by iOS－38 on 15/11/15.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "SlowNetModel.h"

@implementation SlowNetModel
+(id)getSlowDataWithPageId:(NSInteger)pageId completionHandle:(void (^)(id, NSError *))completionHandle{

    NSString *path = [NSString stringWithFormat:@"http://app.api.autohome.com.cn/autohdv2.6/dealer/pricedownlist-a4-pm5-v2.6.1-pi0-c0-o0-os0-ss0-sp0-p%ld-s20-b0-l0-maxp0-minp0.html",pageId];
return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
    completionHandle([SlowModel objectWithKeyValues:responseObj],error);
}];
}
@end
