//
//  CarPriceNetModel.m
//  BaseProject
//
//  Created by iOS－38 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "CarPriceNetModel.h"

@implementation CarPriceNetModel

+(id)getPriceDataWithPageIndex:(NSInteger)priceIndex completionHandle:(void (^)(id, NSError *))completionHandle{
    NSString *path = [NSString stringWithFormat:@"http://app.api.autohome.com.cn/autohdv2.6/cars/getseries-a4-pm5-v2.6.1-b0-o2-p%ld-s20.html",priceIndex];

return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
    completionHandle([CarPriceModel objectWithKeyValues:responseObj],error);
}];


}


@end
