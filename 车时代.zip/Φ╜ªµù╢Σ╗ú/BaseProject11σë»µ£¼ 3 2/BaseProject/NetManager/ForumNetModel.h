//
//  ForumNetModel.h
//  BaseProject
//
//  Created by iOS－38 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "ForumModel.h"


@interface ForumNetModel : BaseNetManager



+(id)getForumDataWithPageIndex:(NSInteger)pageindex kCompletionHandle;

@end
