//
//  CarPriceNetModel.h
//  BaseProject
//
//  Created by iOS－38 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "CarPriceModel.h"

@interface CarPriceNetModel : BaseNetManager


+(id)getPriceDataWithPageIndex:(NSInteger)priceIndex kCompletionHandle;
@end
