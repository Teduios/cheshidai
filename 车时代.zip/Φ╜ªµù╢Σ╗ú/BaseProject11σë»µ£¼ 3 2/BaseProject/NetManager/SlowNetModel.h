//
//  SlowNetModel.h
//  BaseProject
//
//  Created by iOS－38 on 15/11/15.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "SlowModel.h"

@interface SlowNetModel : BaseNetManager
+(id)getSlowDataWithPageId:(NSInteger)pageId kCompletionHandle;
@end
