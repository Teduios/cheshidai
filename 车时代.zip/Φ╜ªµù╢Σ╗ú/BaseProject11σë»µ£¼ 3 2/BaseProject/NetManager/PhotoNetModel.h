//
//  PhotoNetModel.h
//  BaseProject
//
//  Created by iOS－38 on 15/11/15.
//  Copyright © 2015年 Tarena. All rights reserved.
//
// http://app.api.autohome.com.cn/autohdv2.6/cars/newestseriespic-a4-pm5-v2.6.1-s18.html

// http://app.api.autohome.com.cn/autohdv2.6/cars/newestseriespic-a4-pm5-v2.6.1-s5.html
#import "BaseNetManager.h"
#import "PhotoModel.h"

@interface PhotoNetModel : BaseNetManager
+(id)getPhotoWithPageId:(NSInteger)pageId kCompletionHandle;

@end
