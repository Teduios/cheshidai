//
//  PhotoNetModel.m
//  BaseProject
//
//  Created by iOS－38 on 15/11/15.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "PhotoNetModel.h"

@implementation PhotoNetModel
+(id)getPhotoWithPageId:(NSInteger)pageId completionHandle:(void (^)(id, NSError *))completionHandle{
    NSString *path = [NSString stringWithFormat:@"http://app.api.autohome.com.cn/autohdv2.6/cars/newestseriespic-a4-pm5-v2.6.1-s%ld.html",pageId];
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([PhotoModel objectWithKeyValues:responseObj],error);
    }];

}

@end
