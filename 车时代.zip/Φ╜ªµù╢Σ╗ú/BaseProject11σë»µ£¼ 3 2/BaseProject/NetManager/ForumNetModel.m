//
//  ForumNetModel.m
//  BaseProject
//
//  Created by iOS－38 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ForumNetModel.h"
#import "ForumModel.h"

@implementation ForumNetModel


+(id)getForumDataWithPageIndex:(NSInteger)pageindex completionHandle:(void (^)(id, NSError *))completionHandle{
    NSString *path = [ NSString stringWithFormat:@"http://app.api.autohome.com.cn/autohdv2.6/club/jingxuantopic-a4-pm5-v2.6.1-c0-p%ld-s15.html",pageindex];
return  [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
    completionHandle([ForumModel objectWithKeyValues:responseObj],error);
}];
}


@end
