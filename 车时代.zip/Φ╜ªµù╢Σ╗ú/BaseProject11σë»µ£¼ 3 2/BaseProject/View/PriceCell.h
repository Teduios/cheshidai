//
//  PriceCell.h
//  BaseProject
//
//  Created by iOS－38 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WGImageView.h"

@interface PriceCell : UITableViewCell
@property(nonatomic,strong)WGImageView *iconIV;
@property(nonatomic,strong)UILabel *titleLb;
@property(nonatomic,strong)UILabel *noneLb;

@property(nonatomic,strong)UILabel *breadnameLb;
@property(nonatomic,strong)UILabel *fctnameLb;
@property(nonatomic,strong)UILabel *structLb;
@property(nonatomic,strong)UILabel *levelLb;
@property(nonatomic,strong)UILabel *priceLb;
@property(nonatomic,strong)UILabel *gearboxLb;
@property(nonatomic,strong)UILabel *displamentLb;
@end










