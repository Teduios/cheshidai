//
//  SlowCell.m
//  BaseProject
//
//  Created by iOS－38 on 15/11/15.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "SlowCell.h"

@implementation SlowCell
- (UIImageView *)iconIV {
    if(_iconIV == nil) {
        _iconIV = [[UIImageView alloc] init];
        [self.contentView addSubview:_iconIV];
        [_iconIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(10);
            make.left.mas_equalTo(5);
            make.centerY.mas_equalTo(0);
           
        }];
    }
    return _iconIV;
}

- (UILabel *)seriesLb {
    if(_seriesLb == nil) {
        _seriesLb = [[UILabel alloc] init];
        _seriesLb.font = [UIFont systemFontOfSize:13];
        [self.contentView addSubview:_seriesLb];
        [_seriesLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.topMargin.mas_equalTo(self.iconIV.mas_topMargin);
            make.left.mas_equalTo(self.iconIV.mas_right).mas_equalTo(5);
            make.width.mas_lessThanOrEqualTo(90);
            
            
        }];
    }
    return _seriesLb;
}

- (UILabel *)speanameLb {
    if(_speanameLb == nil) {
        _speanameLb = [[UILabel alloc] init];
        _speanameLb.font = [UIFont systemFontOfSize:13];
        _speanameLb.numberOfLines = 1;
        [self.contentView addSubview:_speanameLb];
        [_speanameLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.topMargin.mas_equalTo(self.iconIV.mas_topMargin);
            make.left.mas_equalTo(self.seriesLb.mas_right).mas_equalTo(5);
            make.width.mas_lessThanOrEqualTo(190);
        }];
    }
    return _speanameLb;
}

- (UILabel *)companyLb {
    if(_companyLb == nil) {
        _companyLb = [[UILabel alloc] init];
        _companyLb.font = [UIFont systemFontOfSize:13];
        [self.contentView addSubview:_companyLb];
        [_companyLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leftMargin.mas_equalTo(self.seriesLb.mas_leftMargin);
            make.top.mas_equalTo(self.seriesLb.mas_bottom).mas_equalTo(10);
            make.width.mas_equalTo(140);
            make.height.mas_equalTo(20);
        }];
    }
    return _companyLb;
}

- (UILabel *)phoneLb {
    if(_phoneLb == nil) {
        _phoneLb = [[UILabel alloc] init];
        _phoneLb.textColor = [UIColor redColor];
        _phoneLb.font = [UIFont systemFontOfSize:13];
        [self.contentView addSubview:_phoneLb];
        [_phoneLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leftMargin.mas_equalTo(self.seriesLb.mas_leftMargin);
            make.bottomMargin.mas_equalTo(self.iconIV);
            make.width.mas_equalTo(120);
        }];
        UIImageView *imageView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"1"]];
        [_phoneLb addSubview:imageView];
        [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-8);
            make.centerY.mas_equalTo(0);
            make.size.mas_equalTo(CGSizeMake(12, 12));
        }];
    }
    return _phoneLb;
}

- (UILabel *)nowPriceLb {
    if(_nowPriceLb == nil) {
        _nowPriceLb = [[UILabel alloc] init];
        _nowPriceLb.font = [UIFont systemFontOfSize:13];
        _nowPriceLb.textColor = [UIColor redColor];
        [self.contentView addSubview:_nowPriceLb];
        [_nowPriceLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.companyLb.mas_right).mas_equalTo(5);
            make.topMargin.mas_equalTo(self.companyLb.mas_topMargin);
            make.centerY.mas_equalTo(self.companyLb);
        }];
    }
    return _nowPriceLb;
}

- (UILabel *)oldPriceLb {
    if(_oldPriceLb == nil) {
        _oldPriceLb = [[UILabel alloc] init];
        _oldPriceLb.font = [UIFont systemFontOfSize:13];
        _oldPriceLb.textColor = [UIColor lightGrayColor];
        [self.contentView addSubview:_oldPriceLb];
        [_oldPriceLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leftMargin.mas_equalTo(self.nowPriceLb.mas_leftMargin);
            make.topMargin.mas_equalTo(self.phoneLb.mas_topMargin);
            make.centerY.mas_equalTo(self.phoneLb);
        }];
    }
    return _oldPriceLb;
}

- (UILabel *)cityLb {
    if(_cityLb == nil) {
        _cityLb = [[UILabel alloc] init];
        [self.contentView addSubview:_cityLb];
        _cityLb.font = [UIFont systemFontOfSize:15];
        [self.contentView addSubview:_cityLb];
        [_cityLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-10);
            make.size.mas_equalTo(CGSizeMake(40, 40));
            make.topMargin.mas_equalTo(self.iconIV.mas_topMargin);
        }];
    }
    return _cityLb;
}



- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
