//
//  ForumCell.m
//  BaseProject
//
//  Created by iOS－38 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ForumCell.h"
//np_toolbar_comment_h 评论
//registerAndLogin_password_show_textfield  眼睛
@implementation ForumCell

- (WGImageView *)iconIV {
    if(_iconIV == nil) {
        _iconIV = [[WGImageView alloc] init];
        [self.contentView addSubview:_iconIV];
        [_iconIV mas_makeConstraints:^(MASConstraintMaker *make) {
            //make.left.right.top.mas_equalTo(0);
            make.left.top.mas_equalTo(5);
            make.right.mas_equalTo(-5);
            make.height.mas_equalTo(_iconIV.mas_width);
        }];
    }
    return _iconIV;
}

- (UILabel *)titleLb {
    if(_titleLb == nil) {
        _titleLb = [[UILabel alloc] init];
        _titleLb.font = [UIFont systemFontOfSize:15];
        [self.contentView addSubview:_titleLb];
        [_titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(10);
            make.top.mas_equalTo(self.iconIV.mas_bottom).mas_equalTo(5);
            make.right.mas_equalTo(-10);
            make.height.mas_equalTo(10);
        }];
    }
    return _titleLb;
}

//- (UILabel *)scanLb {
//    if(_scanLb == nil) {
//        _scanLb = [[UILabel alloc] init];
//        [self.contentView addSubview:_scanLb];
//        [_scanLb mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.top.mas_equalTo(self.titleLb.mas_bottom).mas_equalTo(5);
//            make.leftMargin.mas_equalTo(self.titleLb.mas_leftMargin);
//            make.width.mas_lessThanOrEqualTo(50);
//        }];
//    }
//    return _scanLb;
//}
//
//- (UILabel *)commentLb {
//    if(_commentLb == nil) {
//        _commentLb = [[UILabel alloc] init];
//        [self.contentView addSubview:_commentLb];
//        [_commentLb mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.centerY.mas_equalTo(self.scanLb);
//            make.right.mas_equalTo(20);
//            
//        }];
//    }
//    return _commentLb;
//}



//- (WGImageView *)iconIV {
//    if(_iconIV == nil) {
//        _iconIV = [[WGImageView alloc] init];
//        [self.contentView addSubview:_iconIV];
//        [_iconIV mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.left.top.right.mas_equalTo(0);
//            make.height.mas_equalTo(60);
//        }];
//    }
//    
//    return _iconIV;
//}
//
//- (UILabel *)titleLb {
//    if(_titleLb == nil) {
//        _titleLb = [[UILabel alloc] init];
//        [self.contentView addSubview:_titleLb];
//        
//        [_titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.left.mas_equalTo(10);
//            make.right.mas_equalTo(-10);
//            make.top.mas_equalTo(self.iconIV.mas_bottom).mas_equalTo(3);
//            
//        }];
//    }
//    return _titleLb;
//}
//
//- (UILabel *)scanLb {
//    if(_scanLb == nil) {
//        _scanLb = [[UILabel alloc] init];
//        _scanLb.font = [UIFont systemFontOfSize:15];
//        _scanLb.textColor = [UIColor blueColor];
//        UIImageView *imageView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"registerAndLogin_password_show_textfield"]];
//        [_scanLb addSubview:imageView];
//        [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.leftMargin.mas_equalTo(self.titleLb.mas_leftMargin);
//            make.size.mas_equalTo(CGSizeMake(20, 20));
//            make.bottom.mas_equalTo(-2);
//            make.top.mas_equalTo(self.titleLb.mas_bottom).mas_equalTo(2);
//        }];
//        [self.contentView addSubview:_scanLb];
//        [_scanLb mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.centerY.mas_equalTo(imageView);
//            make.left.mas_equalTo(imageView.mas_right).mas_equalTo(2);
//        }];
//    }
//    return _scanLb;
//}
//
//- (UILabel *)commentLb {
//    if(_commentLb == nil) {
//        _commentLb = [[UILabel alloc] init];
//        UIImageView *imageView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"np_toolbar_comment_h"]];
//        [_commentLb addSubview:imageView];
//        [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.centerY.mas_equalTo(self.scanLb);
//            make.right.mas_equalTo(20);
//            make.size.mas_equalTo(CGSizeMake(25, 25));
//            
//        }];
//        [self.contentView addSubview:_commentLb];
//        [_commentLb mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.centerY.mas_equalTo(imageView);
//            make.left.mas_equalTo(imageView.mas_right).mas_equalTo(2);
//        }];
//    }
//    return _commentLb;
//}
@end
