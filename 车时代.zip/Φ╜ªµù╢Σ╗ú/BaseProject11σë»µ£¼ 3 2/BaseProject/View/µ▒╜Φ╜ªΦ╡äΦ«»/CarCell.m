//
//  CarCell.m
//  BaseProject
//
//  Created by iOS－38 on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "CarCell.h"

@implementation CarCell
- (UIImageView *)iconIV {
    if(_iconIV == nil) {
        _iconIV = [[UIImageView alloc] init];
        [self.contentView addSubview:_iconIV];
        [_iconIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(80, 60));
            make.left.mas_equalTo(10);
            make.centerY.mas_equalTo(0);
        }];
    }
    return _iconIV;
}

- (UILabel *)titleLb {
    if(_titleLb == nil) {
        _titleLb = [[UILabel alloc] init];
        [self.contentView addSubview:_titleLb];
        _titleLb.font = [UIFont systemFontOfSize:15];
        [_titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.topMargin.mas_equalTo(self.iconIV);
            
            make.left.mas_equalTo(self.iconIV.mas_right).mas_equalTo(10);
           
            make.right.mas_equalTo(-20);
            
        }];
        _titleLb.numberOfLines = 2;
    }
    return _titleLb;
}

- (UILabel *)dateLb {
    if(_dateLb == nil) {
        _dateLb = [[UILabel alloc] init];
        _dateLb.textColor = [UIColor lightGrayColor];
        _dateLb.font = [UIFont systemFontOfSize:13];
        [self.contentView addSubview:_dateLb];
        [_dateLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leftMargin.mas_equalTo(self.titleLb);
            make.bottomMargin.mas_equalTo(self.iconIV);
            make.width.mas_lessThanOrEqualTo(70);
        }];
    }
    return _dateLb;
}

- (UILabel *)commentLb {
    if(_commentLb == nil) {
        _commentLb = [[UILabel alloc] init];
        _commentLb.font = [UIFont systemFontOfSize:13];
        _commentLb.textColor = [UIColor lightGrayColor];
        _commentLb.textAlignment = NSTextAlignmentRight;
        [self.contentView addSubview:_commentLb];
        
        [_commentLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottomMargin.mas_equalTo(self.iconIV);
            make.right.mas_equalTo(-20);
            
        }];
    }
    return _commentLb;
}




- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
