//
//  CarCell.h
//  BaseProject
//
//  Created by iOS－38 on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface CarCell : UITableViewCell
//左侧的图片
@property(nonatomic,strong)UIImageView *iconIV;
//标题
@property(nonatomic,strong)UILabel *titleLb;
//时间
@property(nonatomic,strong)UILabel *dateLb;
//评论数
@property(nonatomic,strong)UILabel *commentLb;


@end
