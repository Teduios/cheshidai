//
//  PriceCell.m
//  BaseProject
//
//  Created by iOS－38 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "PriceCell.h"

@implementation PriceCell
//图片
- (WGImageView *)iconIV {
    if(_iconIV == nil) {
        _iconIV = [[WGImageView alloc] init];
        [self.contentView addSubview:_iconIV];
        [_iconIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(5);
            make.top.mas_equalTo(10);
            make.size.mas_equalTo(CGSizeMake(110, 65));
            make.centerY.mas_equalTo(0);
        }];
    }
    return _iconIV;
}
//题目
- (UILabel *)titleLb {
    if(_titleLb == nil) {
        _titleLb = [[UILabel alloc] init];
        _titleLb.font = [UIFont systemFontOfSize:15];
        [self.contentView addSubview:_titleLb];
        [_titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.topMargin.mas_equalTo(self.iconIV.mas_topMargin);
            make.left.mas_equalTo(self.iconIV.mas_right).mas_equalTo(3);
            make.width.mas_lessThanOrEqualTo(80);
        }];
    }
    return _titleLb;
}
//指导价
- (UILabel *)noneLb {
    if(_noneLb == nil) {
        _noneLb = [[UILabel alloc] init];
        _noneLb.font = [UIFont systemFontOfSize:15];
        [self.contentView addSubview:_noneLb];
        [_noneLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-10);
            make.topMargin.mas_equalTo(self.iconIV.mas_topMargin);
        }];
    }
    return _noneLb;
}
////品牌名
- (UILabel *)breadnameLb {
    if(_breadnameLb == nil) {
        _breadnameLb = [[UILabel alloc] init];
        _breadnameLb.font = [UIFont systemFontOfSize:12];
        _breadnameLb.textColor = [UIColor lightGrayColor];
        [self.contentView addSubview:_breadnameLb];
        [_breadnameLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leftMargin.mas_equalTo(self.titleLb.mas_leftMargin);
            make.top.mas_equalTo(self.titleLb.mas_bottom).mas_equalTo(5);
            make.width.mas_equalTo(80);
            make.height.mas_lessThanOrEqualTo(20);
        }];
    }
    return _breadnameLb;
}
//厂商
- (UILabel *)fctnameLb {
    if(_fctnameLb == nil) {
        _fctnameLb = [[UILabel alloc] init];
        _fctnameLb.font = [UIFont systemFontOfSize:12];
        _fctnameLb.textColor = [UIColor lightGrayColor];
        [self.contentView addSubview:_fctnameLb];
        [_fctnameLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.breadnameLb.mas_right).mas_equalTo(30);
            make.centerY.mas_equalTo(self.breadnameLb);
            make.topMargin.mas_equalTo(self.breadnameLb.mas_topMargin);
        }];
    }
    return _fctnameLb;
}
////车身结构
- (UILabel *)structLb {
    if(_structLb == nil) {
        _structLb = [[UILabel alloc] init];
        _structLb.font = [UIFont systemFontOfSize:12];
        _structLb.textColor = [UIColor lightGrayColor];
        [self.contentView addSubview:_structLb];
        [_structLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leftMargin.mas_equalTo(self.titleLb.mas_leftMargin);
            make.top.mas_equalTo(self.breadnameLb.mas_bottom).mas_equalTo(5);
            make.width.mas_equalTo(100);
        }];
    }
    return _structLb;
}
////级别
- (UILabel *)levelLb {
    if(_levelLb == nil) {
        _levelLb = [[UILabel alloc] init];
        _levelLb.font = [UIFont systemFontOfSize:12];
        _levelLb.textColor = [UIColor lightGrayColor];
        [self.contentView addSubview:_levelLb];
        [_levelLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leftMargin.mas_equalTo(self.fctnameLb.mas_leftMargin);
            make.centerY.mas_equalTo(self.structLb);
            make.topMargin.mas_equalTo(self.structLb);
        }];
    }
    return _levelLb;
}

- (UILabel *)priceLb {
    if(_priceLb == nil) {
        _priceLb = [[UILabel alloc] init];
        
        _priceLb.textColor = [UIColor redColor];
        _priceLb.font = [UIFont systemFontOfSize:12];
        [self.contentView addSubview:_priceLb];
        [_priceLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leftMargin.mas_equalTo(self.noneLb.mas_leftMargin);
            make.centerY.mas_equalTo(self.structLb);
            make.topMargin.mas_equalTo(self.levelLb.mas_topMargin);
        }];
    }
    return _priceLb;
}
////变速箱
- (UILabel *)gearboxLb {
    if(_gearboxLb == nil) {
        _gearboxLb = [[UILabel alloc] init];
        _gearboxLb.font = [UIFont systemFontOfSize:12];
        _gearboxLb.textColor = [UIColor lightGrayColor];
        [self.contentView addSubview:_gearboxLb];
        [_gearboxLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leftMargin.mas_equalTo(self.titleLb.mas_leftMargin);
            make.top.mas_equalTo(self.structLb.mas_bottom).mas_equalTo(5);
            make.width.mas_lessThanOrEqualTo(100);
        }];
    }
    return _gearboxLb;
}
////发动机
- (UILabel *)displamentLb {
    if(_displamentLb == nil) {
        _displamentLb = [[UILabel alloc] init];
        _displamentLb.font = [UIFont systemFontOfSize:12];
        _displamentLb.textColor = [UIColor lightGrayColor];
        [self.contentView addSubview:_displamentLb];
        [_displamentLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leftMargin.mas_equalTo(self.levelLb.mas_leftMargin);
            make.centerY.mas_equalTo(self.gearboxLb);
            make.topMargin.mas_equalTo(self.gearboxLb.mas_topMargin);
        }];
    }
    return _displamentLb;
}












- (void)awakeFromNib {
    // Initialization code
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    // Configure the view for the selected state
}

@end
