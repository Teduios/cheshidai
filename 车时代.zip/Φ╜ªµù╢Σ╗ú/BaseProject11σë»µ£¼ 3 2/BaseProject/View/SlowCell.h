//
//  SlowCell.h
//  BaseProject
//
//  Created by iOS－38 on 15/11/15.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WGImageView.h"

@interface SlowCell : UITableViewCell
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier;

//@property (nonatomic, copy) NSString *seriesname;
@property(nonatomic,strong)UIImageView *iconIV;
//云100
@property(nonatomic,strong)UILabel *seriesLb;
//基本款
@property(nonatomic,strong)UILabel *speanameLb;
//公司
@property(nonatomic,strong)UILabel *companyLb;
@property(nonatomic,strong)UILabel *phoneLb;
@property(nonatomic,strong)UILabel *nowPriceLb;
@property(nonatomic,strong)UILabel *oldPriceLb;

@property(nonatomic,strong)UILabel *cityLb;















@end
