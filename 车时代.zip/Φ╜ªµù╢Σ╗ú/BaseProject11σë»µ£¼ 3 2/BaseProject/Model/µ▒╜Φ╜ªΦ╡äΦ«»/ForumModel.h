//
//  ForumModel.h
//  BaseProject
//
//  Created by iOS－38 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"


@class CarResultModel,CarResultAdModel,CarResultListModel;
@interface ForumModel : BaseModel

@property (nonatomic, copy) NSString *message;
@property (nonatomic, assign) NSInteger returncode;
@property (nonatomic, strong) CarResultModel *result;



@end

@interface CarResultModel : NSObject

@property (nonatomic, assign) NSInteger pagecount;
@property (nonatomic, assign) NSInteger rowcount;
@property (nonatomic, strong) NSArray<CarResultListModel *> *list;
@property (nonatomic, strong) CarResultAdModel *ad;
@property (nonatomic, assign) NSInteger pageindex;
@end



@interface CarResultAdModel : NSObject
//将系统关键字去掉
@property (nonatomic, assign) NSInteger ID;
//@property (nonatomic, assign) NSInteger id;
@property (nonatomic, copy) NSString *pubtime;
@property (nonatomic, assign) NSInteger replycount;
@property (nonatomic, assign) NSInteger jumptype;
@property (nonatomic, copy) NSString *url;
@property (nonatomic, copy) NSString *imgpath;
@property (nonatomic, assign) NSInteger type;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, assign) NSInteger adtype;
@property (nonatomic, assign) NSInteger bbsid;
@property (nonatomic, copy) NSString *shorttitle;
@property (nonatomic, assign) NSInteger isshow;
@property (nonatomic, assign) NSInteger objid;
@end

@interface CarResultListModel : NSObject
//图片地址
@property (nonatomic, copy) NSString *smallpic;
@property (nonatomic, assign) NSInteger isclosed;
@property (nonatomic, assign) NSInteger postmemberid;
@property (nonatomic, copy) NSString *imgurl;
@property (nonatomic, copy) NSString *postusername;
@property (nonatomic, assign) NSInteger topicid;
@property (nonatomic, copy) NSString *bbstype;
//图片下的文字
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *lastreplydate;
@property (nonatomic, copy) NSString *bigpic;
@property (nonatomic, copy) NSString *topictype;
@property (nonatomic, assign) NSInteger bbsid;
@property (nonatomic, copy) NSString *bbsname;
//评论数
@property (nonatomic, assign) NSInteger replycounts;
//被观看的人数
@property (nonatomic, assign) NSInteger views;
@end

