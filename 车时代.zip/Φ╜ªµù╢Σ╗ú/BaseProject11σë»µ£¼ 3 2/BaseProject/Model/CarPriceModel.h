//
//  CarPriceModel.h
//  BaseProject
//
//  Created by iOS－38 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class PriceResultModel,PriceResultListModel;


@interface CarPriceModel : BaseModel
@property (nonatomic, strong) PriceResultModel *result;
@property (nonatomic, assign) NSInteger returncode;
@property (nonatomic, copy) NSString *message;
@end






@interface PriceResultModel : NSObject
@property (nonatomic, assign) NSInteger rowcount;
@property (nonatomic, assign) NSInteger pagecount;
@property (nonatomic, strong) NSArray<PriceResultListModel *> *list;
@property (nonatomic, assign) NSInteger pageindex;
@end




@interface PriceResultListModel : NSObject
//最大价格
@property (nonatomic, assign) NSInteger maxprice;
//图片地址
@property (nonatomic, copy) NSString *img;
@property (nonatomic, assign) NSInteger ID;
//@property (nonatomic, assign) NSInteger id;
//最小价格
@property (nonatomic, assign) NSInteger minprice;
//厂商
@property (nonatomic, copy) NSString *fctname;
//级别
@property (nonatomic, copy) NSString *level;
//车身结构
@property (nonatomic, strong) NSArray<NSString *> *structure;
//变速箱
@property (nonatomic, strong) NSArray<NSString *> *gearbox;
//发动机
@property (nonatomic, strong) NSArray<NSString *> *displacement;
//题目
@property (nonatomic, copy) NSString *name;
//品牌名
@property (nonatomic, copy) NSString *brandname;
@end













