//
//  SlowModel.m
//  BaseProject
//
//  Created by iOS－38 on 15/11/15.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "SlowModel.h"

@implementation SlowModel

@end
@implementation SlowResultmodel

+ (NSDictionary *)objectClassInArray{
    return @{@"list" : [SlowResultListmodel class]};
}

@end


@implementation SlowResultListmodel

@end


