//
//  PhotoModel.h
//  BaseProject
//
//  Created by iOS－38 on 15/11/15.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class PhotoResultModel,PhotoResultSeriesitemsModel;


@interface PhotoModel : BaseModel
@property (nonatomic, strong) PhotoResultModel *result;
@property (nonatomic, assign) NSInteger returncode;
@property (nonatomic, copy) NSString *message;
@end



@interface PhotoResultModel : NSObject
@property (nonatomic, strong) NSArray<PhotoResultSeriesitemsModel *> *seriesitems;
@end




@interface PhotoResultSeriesitemsModel : NSObject
@property (nonatomic, assign) NSInteger ID;
//@property (nonatomic, assign) NSInteger id;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *picfilepath;
@property (nonatomic, copy) NSString *dtime;
@end

