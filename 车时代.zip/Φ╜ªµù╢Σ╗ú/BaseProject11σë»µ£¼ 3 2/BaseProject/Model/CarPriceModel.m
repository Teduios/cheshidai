//
//  CarPriceModel.m
//  BaseProject
//
//  Created by iOS－38 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "CarPriceModel.h"

@implementation CarPriceModel

@end
@implementation PriceResultModel

+ (NSDictionary *)objectClassInArray{
    return @{@"list" : [PriceResultListModel class]};
}

@end


@implementation PriceResultListModel
+(NSDictionary *)replacedKeyFromPropertyName{
    return @{@"ID":@"id"};
}
@end


