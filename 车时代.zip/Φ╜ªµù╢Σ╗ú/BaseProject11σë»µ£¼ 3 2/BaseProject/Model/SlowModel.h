//
//  SlowModel.h
//  BaseProject
//
//  Created by iOS－38 on 15/11/15.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class SlowResultmodel,SlowResultListmodel;

@interface SlowModel : BaseModel
@property (nonatomic, strong) SlowResultmodel *result;
@property (nonatomic, assign) NSInteger returncode;
@property (nonatomic, copy) NSString *message;

@end
@interface SlowResultmodel : NSObject
@property (nonatomic, assign) NSInteger pagecount;
@property (nonatomic, assign) NSInteger rowcount;
@property (nonatomic, strong) NSArray<SlowResultListmodel *> *list;
@property (nonatomic, assign) NSInteger pageindex;
@end




@interface SlowResultListmodel : NSObject

@property (nonatomic, copy) NSString *company;

@property (nonatomic, assign) NSInteger orderrange;


@property (nonatomic, assign) BOOL hasimsaler;

@property (nonatomic, assign) NSInteger is24h;

@property (nonatomic, assign) NSInteger specid;


@property (nonatomic, assign) NSInteger isauth;

@property (nonatomic, assign) NSInteger priceoffpercent;

@property (nonatomic, assign) CGFloat maplatbaidu;

@property (nonatomic, copy) NSString *publishtime;

@property (nonatomic, assign) NSInteger closeorder;

@property (nonatomic, copy) NSString *appsellphone;

@property (nonatomic, copy) NSString *assellphone;


@property (nonatomic, assign) NSInteger seriesid;

@property (nonatomic, copy) NSString *styledinventorystate;

@property (nonatomic, assign) CGFloat maplonbaidu;

@property (nonatomic, assign) NSInteger newstype;

@property (nonatomic, assign) NSInteger dealerid;

@property (nonatomic, copy) NSString *startdate;

@property (nonatomic, copy) NSString *styledsellphone;

@property (nonatomic, assign) NSInteger orderslastmonth;

@property (nonatomic, assign) NSInteger inventorystate;

@property (nonatomic, copy) NSString *orderrangetitle;


@property (nonatomic, assign) NSInteger cityid;

@property (nonatomic, assign) NSInteger orderslastquarter;

@property (nonatomic, copy) NSString *enddate;


@property (nonatomic, assign) NSInteger brandid;
//公司名称
@property (nonatomic, copy) NSString *companysimple;
//现价
@property (nonatomic, copy) NSString *price;
//图片
@property (nonatomic, copy) NSString *specimage;
//原价
@property (nonatomic, copy) NSString *originalprice;
//2014款 基本型
@property (nonatomic, copy) NSString *specname;
//联系电话
@property (nonatomic, copy) NSString *sellphone;
//城市名称
@property (nonatomic, copy) NSString *cityname;
//云100
@property (nonatomic, copy) NSString *seriesname;

@property (nonatomic, assign) NSInteger newsid;

@end

