//
//  PhotoModel.m
//  BaseProject
//
//  Created by iOS－38 on 15/11/15.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "PhotoModel.h"

@implementation PhotoModel

@end
@implementation PhotoResultModel

+ (NSDictionary *)objectClassInArray{
    return @{@"seriesitems" : [PhotoResultSeriesitemsModel class]};
}

@end


@implementation PhotoResultSeriesitemsModel
+(NSDictionary *)replacedKeyFromPropertyName{
    return @{@"ID":@"id"};
}
@end


